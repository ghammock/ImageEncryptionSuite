﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using System.Drawing;
using System.Drawing.Imaging;

namespace makeUniformLuminanceImage
{
    class Program
    {
        private static int[] remainingPixels = new int[256];
        private static Random rand = new Random();

        static void Main(string[] args)
        {
            int size = 0;
            
            if (Int32.TryParse(args[0], out size))
            {
                Bitmap bmp = new Bitmap(size, size);

                for (int i = 0; i < 256; ++i)
                    remainingPixels[i] = (int)(Math.Pow(size, 2) / 256.0);

                int lum = 0;

                for (int y = 0; y < size; ++y)
                {
                    lum = GetNewLuminanceValue();

                    for (int x = 0; x < size; ++x)
                    {
                        bmp.SetPixel(x, y, Color.FromArgb(255, lum, lum, lum));
                        --remainingPixels[lum];
                    }
                }

                bmp.Save("output.png", ImageFormat.Png);
            }
        }

        private static int GetNewLuminanceValue ()
        {
            int luminance = 0;

            do
            {
                luminance = rand.Next(0, 256);
            } while (remainingPixels[luminance] <= 0);

            return luminance;
        }
    }
}
